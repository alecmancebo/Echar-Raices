
export class Overworld {
  constructor(config) {
    this.element = config.element;
    this.canvas = this.element.querySelector(".gameCanvas");
    this.ctx = this.canvas.getContext("2d");
  }

  init() {
    // carga de imágenes y drawImage
    const image = new Image();
    image.onload = () => {
      this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
      this.ctx.drawImage(image, 0, 0);
    };
    image.src = "/public/jardin.png";
    
    // El resto de las imágenes (shadow, hero) van aquí igual...
  }
}